package com.model;

public class BasketDAO {

}
