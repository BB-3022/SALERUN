package com.model;

public class BasketDTO {

}
